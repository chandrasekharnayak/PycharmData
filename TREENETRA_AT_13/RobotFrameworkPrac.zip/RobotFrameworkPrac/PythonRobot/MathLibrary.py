class MathLibrary:

    def add_two_num(self,a,b):
        return int(a)+int(b)

